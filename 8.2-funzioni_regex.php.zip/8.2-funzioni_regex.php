<!--

	Funzioni in PHP
	Primi esempi di espressioni regolari

	Disponibile su devACADEMY.it

-->

<?php

	$pattern="/[a-z]+[0-9]{2}/";

	$username1="silvio23";

	preg_match($pattern, $username1, $r);
	var_dump($r);

	$username2="lucio.d";
	preg_match($pattern, $username2, $r);
	var_dump($r);

	if (preg_match($pattern, $username1))
		echo "$username1 valido";
	else
		echo "$username1 NON valido";

?>