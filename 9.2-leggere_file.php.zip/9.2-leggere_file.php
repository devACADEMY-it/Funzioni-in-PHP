<!--

	Funzioni in PHP
	Lettura di file

	Disponibile su devACADEMY.it

-->

<?php

	if ($file=fopen("dati.txt", "r"))
	{
		while(!feof($file))
		{
			$l=fgets($file);
			echo "$l <br>";
		}
		fclose($file);
	}

?>