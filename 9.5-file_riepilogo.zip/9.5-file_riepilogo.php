<!--

	Funzioni in PHP
	Esempio riepilogativo funzioni per filesystem

	Disponibile su devACADEMY.it

-->

<?php

	$tot=array();
	if ($file=fopen("src.txt","r"))
	{
		while(!feof($file))
		{
			$line=fgets($file);
			$pp=explode(' ', $line);
			if (array_key_exists($pp[0], $tot))
				$tot[$pp[0]]+=$pp[1];
			else
				$tot[$pp[0]]=$pp[1];
		}
		fclose($file);
		ksort($tot);
		var_dump($tot);
	}

?>