<!--

	Funzioni in PHP
	Visibilità delle variabili

	Disponibile su devACADEMY.it

-->

<?php


	function stampaUsername()
	{
		$username="Pippo";
		echo $username;
		echo "<br>";
	}

	stampaUsername();


	echo $username;

?>