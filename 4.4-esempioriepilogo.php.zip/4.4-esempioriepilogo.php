<!--

	Funzioni in PHP
	Esempio riepilogativo funzioni

	Disponibile su devACADEMY.it

-->

<?php

	function totale($carrello)
	{
		$totale=0;
		foreach($carrello as $c)
			$totale+=$c["prezzo"];
		return $totale;
	}

	function aggiungiIVA($prezzo)
	{
		return $prezzo*1.22;
	}

	function fattura($carrello)
	{
		echo "Acquistati n. ".count($carrello)." elementi <br>";
		$totale=totale($carrello);
		echo "Totale IVA esclusa. $totale <br>";
		echo "Totale IVA inclusa ".aggiungiIVA($totale)."<br>";
	}

	$prodotto1=array("descrizione" => "scarpe corsa", "prezzo" => 158);
	$prodotto2=array("descrizione" => "felpa", "prezzo" => 56);
	$prodotto3=array("descrizione" => "tuta", "prezzo" => 134);

	$carrello=array($prodotto1, $prodotto2, $prodotto3);

	fattura($carrello);

?>