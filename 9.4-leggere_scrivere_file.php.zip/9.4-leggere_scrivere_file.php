<!--

	Funzioni in PHP
	Funzioni per leggere e scrivere file in un colpo solo

	Disponibile su devACADEMY.it

-->

<?php

	$dati=file_get_contents("dati.txt");
	echo $dati;
	$bytes=file_put_contents("nuovo.txt", strrev($dati));
	echo "<br> scritti $bytes su disco <br>";

?>