<!--

	Funzioni in PHP
	Operazioni su filesystem

	Disponibile su devACADEMY.it

-->

<?php

	$file="panorama.bmp";

	if (file_exists($file))
		echo "$file esiste <br>";
	else
		echo "$file NON esiste <br>";

	$dir="documenti";
	$lista=scandir($dir);
	var_dump($lista);

	$src=$dir.DIRECTORY_SEPARATOR."file1.txt";
	$dest=$dir.DIRECTORY_SEPARATOR."copia_file1.txt";
	$res=copy($src,$dest);

	if ($res)
		echo "file copiato <br>";
	else
		echo "file non copiato <br>";

	echo "<br>";

	foreach (scandir($dir) as $l)
	{
		if (is_dir($dir.DIRECTORY_SEPARATOR.$l))
			echo "$l (directory) <br>";
		else
		{
			$ff=$dir.DIRECTORY_SEPARATOR.$l;
			printf("%s %d bytes <br>", $l, filesize($ff));
		}


	}

?>