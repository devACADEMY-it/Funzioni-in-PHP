<!--

	Funzioni in PHP
	Esempio riepilogativo funzioni per le date

	Disponibile su devACADEMY.it

-->

<?php

	$ora=mktime(0,0,0,6,15,2018);
	$dati=array();

	$dati[0]=$ora;

	for($i=1; $i<=5; $i++)
	{
		$dati[$i]=strtotime('+5 day', $dati[$i-1]);
		if (date("N", $dati[$i])==6)
		{
			echo "*** Evitato sabato ".date("d/m/Y", $dati[$i]).'<br>';
			$dati[$i]=strtotime('+7 day', $dati[$i-1]);
		}
		else if (date("N", $dati[$i])==7)
		{
			echo "*** Evitata domenica ".date("d/m/Y", $dati[$i]).'<br>';
			$dati[$i]=strtotime('+6 day', $dati[$i-1]);
		}
		echo date("d/m/Y", $dati[$i]).'<br>';
	}
	var_dump($dati);

?>