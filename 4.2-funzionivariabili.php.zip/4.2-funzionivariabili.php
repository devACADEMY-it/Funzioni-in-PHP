<!--

	Funzioni in PHP
	Chiamate a funzioni dinamiche

	Disponibile su devACADEMY.it

-->

<?php

	function mattino()
	{
		echo "Buongiorno a tutti <br>";
	}

	function sera()
	{
		echo "Buonasera a tutti... <br>";
	}

	$nome="sera";

	$nome();
?>