<!--

	Funzioni in PHP
	Funzioni per le date: date, checkdate, etc

	Disponibile su devACADEMY.it

-->

<?php

	$tempo=mktime(10,25,35,11,21,1990);
	echo date("d/m/Y", $tempo);
	echo '<br>';
	echo date("h:i:s", $tempo);
	echo '<br>';
	echo "25/12/1970: ".checkdate(12,25,1990);
	echo '<br>';
	echo "25/58/1970: ".checkdate(58,25,1990);
	echo '<br>';
	$dt=date_create_from_format('d/m/Y', '30/05/2008');
	echo date_format($dt, 'd-m-Y');

?>