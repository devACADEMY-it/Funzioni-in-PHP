<!--

	Funzioni in PHP
	Uso di require

	Disponibile su devACADEMY.it

-->

<?php

	require "da_includere.php";
	require "da_includere.php";

	saluto();

?>