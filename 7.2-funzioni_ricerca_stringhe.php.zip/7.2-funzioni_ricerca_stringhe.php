<!--

	Funzioni in PHP
	Ricerca all’interno di una stringa

	Disponibile su devACADEMY.it

-->

<?php

	$racconto="Francesco andava a trovare la nonna tutti i giorni e le portava la spesa";

	echo "$racconto <br>";
	echo strpos($racconto, 'la');
	echo "<br>";
	echo strpos($racconto, 'la', 28);
	echo "<br>";
	echo stripos($racconto, 'francesco');
	echo "<br>";
	echo strstr($racconto, 'nonna');
	echo "<br>";
	echo strstr($racconto, 'nonna', true);

?>