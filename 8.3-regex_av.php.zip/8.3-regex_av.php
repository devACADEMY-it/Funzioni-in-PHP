<!--

	Funzioni in PHP
	Espressioni regolari più complesse

	Disponibile su devACADEMY.it

-->

<?php

	// 192.168.1.1
	$pattern="/[0-9]{1,3}/";

	preg_match_all($pattern, "192.168.1.1", $r);
	var_dump($r);

?>