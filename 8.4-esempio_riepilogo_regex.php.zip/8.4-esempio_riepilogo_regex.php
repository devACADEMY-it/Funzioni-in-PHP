<!--

	Funzioni in PHP
	Esempio riepilogativo espressioni regolari

	Disponibile su devACADEMY.it

-->

<?php

$persone = <<<DATI
Paolo;Neri;12/10/1971;roma
Enzo;Verdi;05/05/1965;Roma
Elisa;;23/06/1977;Napoli
Silvio;Gialli;02/1953;Torino
Alessia;Bianchi;09/08/1975;Roma
Enea;Neri;30/01/1967;Torino
DATI;

$p=explode(PHP_EOL, $persone);
var_dump($p);

$corretti=array();
$sbagliati=array();

$pattern="/[A-Z][a-z]+;[A-Z][a-z]+;\d{2}\/\d{2}\/\d{4};[A-Z][a-z]+/";

foreach ($p as $i)
{
	if (preg_match($pattern, $i))
		$corretti[]=$i;
	else
		$sbagliati[]=$i;
}

var_dump($corretti);
var_dump($sbagliati);

?>