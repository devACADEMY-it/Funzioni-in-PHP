<!--

	Funzioni in PHP
	isset e unset

	Disponibile su devACADEMY.it

-->

<?php
	$valore=23;

	if (isset($valore))
		echo '$valore esiste <br>';
	else
		echo '$valore NON esiste <br>';

	unset($valore);
	echo "<br> ...eseguito unset... <br>";

	if (isset($valore))
		echo '$valore esiste <br>';
	else
		echo '$valore NON esiste <br>';

	$vettore['primo']="uno";
	$vettore['secondo']="due";

	var_dump($vettore);
	unset($vettore['primo']);
	echo "<br> ...eseguito unset... <br>";
	var_dump($vettore);

	if (isset($vettore['primo']))
		echo 'primo esiste <br>';
	else
		echo 'primo NON esiste <br>';

?>