<!--

	Funzioni in PHP
	Esempio riepilogativo valori di ritorno

	Disponibile su devACADEMY.it

-->

<?php

	function sommaVettore($vettore)
	{
		$tot=0;
		foreach($vettore as $v)
			$tot+=$v;
		return $tot;
	}

	function mediaVettore($vettore)
	{
		return sommaVettore($vettore)/count($vettore);
	}

	$lista=array(10, 6, 8, 23, 11);
	echo "Media del vettore: ".mediaVettore($lista);
?>