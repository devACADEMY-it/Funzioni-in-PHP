<!--

	Funzioni in PHP
	Passaggio per valore e per riferimento

	Disponibile su devACADEMY.it

-->

<?php

	function modificaValore(&$a)
	{
		$a*=5;
		echo "Valore dopo modifica $a <br>";
	}

	$valore=4;

	modificaValore($valore);

	echo "Valore dopo funzione $valore <br>";
?>