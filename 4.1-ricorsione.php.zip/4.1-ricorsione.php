<!--

	Funzioni in PHP
	Ricorsione

	Disponibile su devACADEMY.it

-->

<?php

	function fattoriale($numero)
	{
		echo "fattoriale di $numero <br>";
		if ($numero<2)
			return 1;
		else
			return $numero*fattoriale($numero-1);
	}

	echo fattoriale(5);
?>