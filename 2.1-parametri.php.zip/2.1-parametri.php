<!--

	Funzioni in PHP
	Funzioni con parametri

	Disponibile su devACADEMY.it

-->

<?php

function tabellina($numero, $fino)
{
	for($i=1; $i<=$fino; $i++)
		echo ($i*$numero)."<br>";
}


tabellina(3, 10);

echo "<br>";

tabellina(9, 5);

?>