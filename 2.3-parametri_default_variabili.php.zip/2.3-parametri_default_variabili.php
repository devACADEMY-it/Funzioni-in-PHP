<!--

	Funzioni in PHP
	Parametri con valori di default

	Disponibile su devACADEMY.it

-->

<?php

function tabellina($numero, $fino=10)
{
	for($i=1; $i<=$fino; $i++)
		echo ($i*$numero)."<br>";
}

tabellina(3, 5);

echo "<br>";


tabellina(6);

echo "<br>";

tabellina(9, 7);

?>