<!--

	Funzioni in PHP
	Partizionamento e fusione di stringhe

	Disponibile su devACADEMY.it

-->

<?php

	$dati="Un saluto a tutti";
	$parti=explode(' ', $dati);
	var_dump($parti);

	$intera=implode('+',$parti);
	echo $intera;

?>