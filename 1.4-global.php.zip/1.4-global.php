<!--

	Funzioni in PHP
	Variabili global

	Disponibile su devACADEMY.it

-->

<?php

	$username="Topolino";

	function stampaUsername()
	{
		$username="Pippo";
		echo $username;
		echo "<br>";
		global $username;
		echo "valore globale $username";
		echo "valore globale $username";
		echo "<br>";
	}

	stampaUsername();

	echo "Fuori dalla funzione $username";

?>