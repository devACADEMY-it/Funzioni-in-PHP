<!--

	Funzioni in PHP
	Funzioni anonime

	Disponibile su devACADEMY.it

-->

<?php

	$aliquotaSpeciale=4;

	$sommaIVA=function ($prezzo)
	{
		return $prezzo+$prezzo*22/100;
	};

	$sommaIVAConAliquota=function ($prezzo) use ($aliquotaSpeciale)
	{
		return $prezzo+$prezzo*$aliquotaSpeciale/100;
	};

	echo $sommaIVA(2000);

	echo "<br>";

	echo $sommaIVAConAliquota(100);

?>