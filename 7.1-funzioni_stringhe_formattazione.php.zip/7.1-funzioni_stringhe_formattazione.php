<!--

	Funzioni in PHP
	Funzioni di base: lunghezza e formattazione

	Disponibile su devACADEMY.it

-->

<?php

	$num=4;
	$stringa="zampe";

	printf('Di %s il cane ne ha %d', $stringa, $num);
	echo "<br>";
	printf('%05d', $num);
	echo "<br>";
	echo number_format(88123.5674443, 2,',','.');
	echo "<br>";
	list($giorno, $mese, $anno)=sscanf("12/02/1978","%d/%d/%d");
	echo "$giorno <br>";
	echo "$mese <br>";
	echo "$anno <br>";

?>