<!--

	Funzioni in PHP
	Gestire errori con valore di ritorno

	Disponibile su devACADEMY.it

-->

<?php
define("PRIMO_PAR_NON_VALIDO", -1);
define("SECONDO_PAR_NON_VALIDO", -2);

function tabellina($numero, $fino)
{
	if ($numero<=0)
		return PRIMO_PAR_NON_VALIDO;
	else if ($fino<=0)
		return SECONDO_PAR_NON_VALIDO;
	for($i=1; $i<=$fino; $i++)
		echo ($i*$numero)."<br>";
	return 0;
}

$res=tabellina(4,10);

switch($res)
{
	case PRIMO_PAR_NON_VALIDO:
		echo "Primo parametro non valido <br>";
		break;
	case SECONDO_PAR_NON_VALIDO:
		echo "Secondo parametro non valido <br>";
		break;
	case 0:
		echo "Operazioni svolte con successo";

}

?>