<!--

	Funzioni in PHP
	Sintassi delle funzioni

	Disponibile su devACADEMY.it

-->

<?php

	function tabellinaDel2()
	{
	  for($i=1; $i<=10; $i++)
		echo ($i*2)."<br>";
	}

	tabellinaDel2();

	echo "<br><br>";

	tabellinaDel2();

?>