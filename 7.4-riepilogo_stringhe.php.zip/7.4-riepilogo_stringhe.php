<!--

	Funzioni in PHP
	Esempio riepilogativo funzioni per stringhe

	Disponibile su devACADEMY.it

-->

<?php

	$dati[]="ABC s.p.a;13.01;14/03/2017";
	$dati[]="ABC s.p.a;12.56;13/03/2017";
	$dati[]="ABC s.p.a;12.01;12/03/2017";
	$dati[]="ABC s.p.a;11.43;11/03/2017";
	$dati[]="ABC s.p.a;11.78;10/03/2017";

	$totale=0;
	foreach($dati as $d)
	{
		$parti=explode(';',$d);
		$totale+=$parti[1];
	}
	$media=$totale/count($dati);

	printf("Quotazione media su %d giorni equivale a %s euro",
		count($dati),
		number_format($media, 2, ',', '.'));

?>