<!--

	Funzioni in PHP
	Funzioni per il tempo: time, mktime, etc

	Disponibile su devACADEMY.it

-->

<?php

	echo time();
	echo '<br>';
	echo mktime(0,0,0,5,22,1987);
	echo '<br>';
	$diff=mktime(0,0,0,5,22,1987)-mktime(0,0,0,5,22,1986);
	echo $diff;
	echo '<br>';
	echo $diff/3600/24;

?>