<!--

	Funzioni in PHP
	Parametri in numero variabile

	Disponibile su devACADEMY.it

-->

<?php

function sommaTutto()
{
	$totale=0;
	for ($i=0; $i<func_num_args(); $i++)
	{
		$totale+=func_get_arg($i);
	}
	echo "Risultato: $totale";

}

sommaTutto(3,65,18,3);
echo "<br>";
sommaTutto(12,76);
echo "<br>";
sommaTutto(12,76,3,65,18,3);

?>