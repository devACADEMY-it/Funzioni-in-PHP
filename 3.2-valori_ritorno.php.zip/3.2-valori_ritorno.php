<!--

	Funzioni in PHP
	Valori di ritorno

	Disponibile su devACADEMY.it

-->

<?php

function somma($op1, $op2)
{
	$r=$op1+$op2;
	return $r;
}

$risultato=somma(7,15);
echo "Risultato = $risultato";

?>