<!--

	Funzioni in PHP
	Scrivere su file

	Disponibile su devACADEMY.it

-->

<?php

	if ($file=fopen("tabellina.txt", "w"))
	{
		fwrite($file, "Tabellina del 2\r\n");
		for($i=1;$i<=10;$i++)
		{
			fwrite($file, sprintf("%d X 2 = %d\r\n", $i, $i*2));
		}
		fclose($file);
	}

?>