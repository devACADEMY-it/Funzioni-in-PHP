<?php

	$username="pippo";
	
	function saluto()
	{
		echo "un saluto a tutti!! <br>";
	}
	
?>