<!--

	Funzioni in PHP
	Uso di include

	Disponibile su devACADEMY.it

-->

<?php

	include_once "da_includere.php";

	saluto();

?>