<!--

	Funzioni in PHP
	Static

	Disponibile su devACADEMY.it

-->

<?php

	function quanteVolte()
	{
		static $quante=1;
		echo "chiamate alla funzione $quante <br>";
		$quante++;
	}

	quanteVolte();
	quanteVolte();
	quanteVolte();
	quanteVolte();
	quanteVolte();
	quanteVolte();
	quanteVolte();

?>