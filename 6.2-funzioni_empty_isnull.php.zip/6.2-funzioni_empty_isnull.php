<!--

	Funzioni in PHP
	empty, is_null, defined

	Disponibile su devACADEMY.it

-->

<?php
	$falso=false;
	$zero=0;
	$nullo=NULL;
	$stringa="Ciao a tutti";
	define('DEFINITA', 10);

	echo 'empty $falso: '.empty($falso);
	echo "<br>";
	echo 'empty $zero: '.empty($zero);
	echo "<br>";
	echo 'empty $nullo: '.empty($nullo);
	echo "<br>";
	echo 'empty $stringa: '.empty($stringa);
	echo "<br>";
	echo 'is_null $nullo: '.is_null($nullo);
	echo "<br>";
	echo 'is_null $stringa: '.is_null($stringa);
	echo "<br>";

	echo 'Costante definita: '.defined('DEFINITA');
	echo "<br>";
	echo 'Costante non definita: '.defined('NON_DEFINITA');

?>